package com.example.myapplication.modals

class PaymentMethod {
    private var id:Int=0;
}