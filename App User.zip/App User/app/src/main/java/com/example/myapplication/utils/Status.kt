package com.example.myapplication.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}