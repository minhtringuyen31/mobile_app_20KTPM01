package com.example.myapplication.modals

class Cart {
    private var id:Int=0
    private var user_id:Int=0
    override fun toString(): String {
        return "Cart(id=$id, user_id=$user_id)"
    }
}